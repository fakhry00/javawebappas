/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
@Entity 

@NamedQuery(name="findAllTran", query="SELECT u FROM TransactionEntity u")
@NamedQuery(name="findUserTran", query="SELECT u FROM TransactionEntity u  WHERE u.User_id = :User_id ORDER BY u.Tran_No DESC")
@NamedQuery(name="findUserTranto", query="SELECT u FROM TransactionEntity u  WHERE u.Beneficial_No = :Beneficial_No ORDER BY u.Tran_No DESC")
public class TransactionEntity implements Serializable {
    
  
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE) // GenerationType: TABLE, SEQUENCE, IDENTITY or AUTO
    long Tran_No;
    long User_id;
    
    String Date;
    String Tran_Type;
    long Beneficial_No;
    float Amount;
    String Currency;
    float remainderbalance;



    public TransactionEntity() {
    }

    public TransactionEntity( long User_id, String Date, String Tran_Type, long Beneficial_No, float Amount, String Currency, float remainderbalance) {
       
        this.User_id = User_id;
        this.Date = Date;
        this.Tran_Type = Tran_Type;
        this.Beneficial_No = Beneficial_No;
        this.Amount = Amount;
        this.Currency = Currency;
        this.remainderbalance = remainderbalance;
    }

    public long getTran_No() {
        return Tran_No;
    }

    public long getUser_id() {
        return User_id;
    }

    public String getDate() {
        return Date;
    }

    public String getTran_Type() {
        return Tran_Type;
    }

    public long getBeneficial_No() {
        return Beneficial_No;
    }

    public float getAmount() {
        return Amount;
    }

    public String getCurrency() {
        return Currency;
    }

    public float getRemainderbalance() {
        return remainderbalance;
    }

    public void setTran_No(long Tran_No) {
        this.Tran_No = Tran_No;
    }

    public void setUser_id(long User_id) {
        this.User_id = User_id;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public void setTran_Type(String Tran_Type) {
        this.Tran_Type = Tran_Type;
    }

    public void setBeneficial_No(long Beneficial_No) {
        this.Beneficial_No = Beneficial_No;
    }

    public void setAmount(float Amount) {
        this.Amount = Amount;
    }

    public void setCurrency(String Currency) {
        this.Currency = Currency;
    }

    public void setRemainderbalance(float remainderbalance) {
        this.remainderbalance = remainderbalance;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + (int) (this.Tran_No ^ (this.Tran_No >>> 32));
        hash = 37 * hash + (int) (this.User_id ^ (this.User_id >>> 32));
        hash = 37 * hash + Objects.hashCode(this.Date);
        hash = 37 * hash + Objects.hashCode(this.Tran_Type);
        hash = 37 * hash + (int) (this.Beneficial_No ^ (this.Beneficial_No >>> 32));
        hash = 37 * hash + Objects.hashCode(this.Amount);
        hash = 37 * hash + Objects.hashCode(this.Currency);
        hash = 37 * hash + Objects.hashCode(this.remainderbalance);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TransactionEntity other = (TransactionEntity) obj;
        if (this.Tran_No != other.Tran_No) {
            return false;
        }
        if (this.User_id != other.User_id) {
            return false;
        }
        if (this.Beneficial_No != other.Beneficial_No) {
            return false;
        }
        if (!Objects.equals(this.Date, other.Date)) {
            return false;
        }
        if (!Objects.equals(this.Tran_Type, other.Tran_Type)) {
            return false;
        }
        if (!Objects.equals(this.Currency, other.Currency)) {
            return false;
        }
        if (!Objects.equals(this.Amount, other.Amount)) {
            return false;
        }
        return Objects.equals(this.remainderbalance, other.remainderbalance);
    }

    
}
