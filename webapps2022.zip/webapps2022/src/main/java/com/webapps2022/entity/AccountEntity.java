/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;

@Entity
//@Table(name = "Users")
@NamedQuery(name="findAllAccount", query="SELECT u FROM AccountEntity u")
@NamedQuery(name="findUserAccount", query="SELECT u FROM AccountEntity u  WHERE u.UserId = :UserId ")
@NamedQuery(name="updatebalance", query="update AccountEntity u set u.Balance = :Balance where u.UserId =:UserId")
//@NamedQuery(name="findUserBalance", query="SELECT u.Balance FROM AccountEntity u  WHERE u.UserId = :UserId AND u.accoun_id= :accoun_id")
public class AccountEntity implements Serializable{

    @Id
    //@GeneratedValue(strategy = GenerationType.AUTO)
    //private Long accoun_id;
    
    @NotNull
    long UserId;
    
    @NotNull
    float Balance;

    public long getUserId() {
        return UserId;
    }

    public float getBalance() {
        return Balance;
    }

    public void setUserId(long UserId) {
        this.UserId = UserId;
    }

    public void setBalance(float Balance) {
        this.Balance = Balance;
    }
      

    public AccountEntity() {
    }

    public AccountEntity(long UserId, float Balance) {
        //this.accoun_id = id;
        this.UserId = UserId;
        this.Balance = Balance;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + (int) (this.UserId ^ (this.UserId >>> 32));
        hash = 37 * hash + Float.floatToIntBits(this.Balance);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AccountEntity other = (AccountEntity) obj;
        if (this.UserId != other.UserId) {
            return false;
        }
        return Float.floatToIntBits(this.Balance) == Float.floatToIntBits(other.Balance);
    }

    

    
    
}
