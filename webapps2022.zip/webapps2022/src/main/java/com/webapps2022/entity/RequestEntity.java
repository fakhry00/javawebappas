/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
//@Table(name = "Users")
@NamedQuery(name="findAllRequests", query="SELECT u FROM RequestEntity u")
@NamedQuery(name="findRequest", query="SELECT u FROM RequestEntity u  WHERE u.Req_Tran_No = :Req_Tran_No")
@NamedQuery(name="findUserRequests", query="SELECT u FROM RequestEntity u  WHERE u.User_id = :User_id")
@NamedQuery(name="findmyRequests", query="SELECT u FROM RequestEntity u  WHERE u.Benfi_id = :Benfi_id")
@NamedQuery(name="updatestate", query="update RequestEntity u set u.Requ_state = :Requ_state where u.Req_Tran_No =:Req_Tran_No")
public class RequestEntity implements Serializable{


    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE) // GenerationType: TABLE, SEQUENCE, IDENTITY or AUTO
    long Req_Tran_No;
    long User_id;
    String Date;
    String Requ_state;
    float Amount;
    long Benfi_id;
    String Currency;
    public RequestEntity() {
    }

    public RequestEntity(long User_id, String Date, String Requ_state, float Amount, long Benfi_id, String Currency) {
         
        this.User_id = User_id;
        this.Date = Date;
        this.Requ_state = Requ_state;
        this.Amount = Amount;
        this.Benfi_id = Benfi_id;
        this.Currency = Currency;
    }

    public long getReq_Tran_No() {
        return Req_Tran_No;
    }

    public long getUser_id() {
        return User_id;
    }

    public String getDate() {
        return Date;
    }

    public String getRequ_state() {
        return Requ_state;
    }

    public float getAmount() {
        return Amount;
    }

    public long getBenfi_id() {
        return Benfi_id;
    }

    public String getCurrency() {
        return Currency;
    }

    public void setReq_Tran_No(long Req_Tran_No) {
        this.Req_Tran_No = Req_Tran_No;
    }

    public void setUser_id(long User_id) {
        this.User_id = User_id;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public void setRequ_state(String Requ_state) {
        this.Requ_state = Requ_state;
    }

    public void setAmount(float Amount) {
        this.Amount = Amount;
    }

    public void setBenfi_id(long Benfi_id) {
        this.Benfi_id = Benfi_id;
    }

    public void setCurrency(String Currency) {
        this.Currency = Currency;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + (int) (this.Req_Tran_No ^ (this.Req_Tran_No >>> 32));
        hash = 67 * hash + (int) (this.User_id ^ (this.User_id >>> 32));
        hash = 67 * hash + Objects.hashCode(this.Date);
        hash = 67 * hash + Objects.hashCode(this.Requ_state);
        hash = 67 * hash + Float.floatToIntBits(this.Amount);
        hash = 67 * hash + (int) (this.Benfi_id ^ (this.Benfi_id >>> 32));
        hash = 67 * hash + Objects.hashCode(this.Currency);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RequestEntity other = (RequestEntity) obj;
        if (this.Req_Tran_No != other.Req_Tran_No) {
            return false;
        }
        if (this.User_id != other.User_id) {
            return false;
        }
        if (Float.floatToIntBits(this.Amount) != Float.floatToIntBits(other.Amount)) {
            return false;
        }
        if (this.Benfi_id != other.Benfi_id) {
            return false;
        }
        if (!Objects.equals(this.Date, other.Date)) {
            return false;
        }
        if (!Objects.equals(this.Requ_state, other.Requ_state)) {
            return false;
        }
        return Objects.equals(this.Currency, other.Currency);
    }
    
   
}
