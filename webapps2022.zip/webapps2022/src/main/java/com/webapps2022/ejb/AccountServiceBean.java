/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.AccountEntity;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless 
public class AccountServiceBean implements AccountService{
    
    @PersistenceContext
    EntityManager em;

    public AccountServiceBean() {
    }
    
    @Override
    public List<AccountEntity> getAcountList() {
        List <AccountEntity> AllAccount = em.createNamedQuery("findAllAccount").getResultList();
        return AllAccount;
    }
    
    
    @Override
    public void InsertAccount(long UserId, float Balance) {
        AccountEntity NewAccount = new AccountEntity(UserId,Balance);
        em.persist(NewAccount);
        System.out.println("The account has been created");
    }
    
    @Override
    public List <AccountEntity> findUserAccount(long UserId) {
    List <AccountEntity> useraccount = em.createNamedQuery("findUserAccount",  AccountEntity.class).setParameter("UserId", UserId).getResultList();
    //UserEntity firstUserFromList = usersList.get(0);
    return useraccount; //firstUserFromList;
    }
    
    @Override
    public void updatebalance(long UserId, float Balance) {
      em.createNamedQuery("updatebalance",  AccountEntity.class).setParameter("UserId", UserId).setParameter("Balance", Balance).executeUpdate();
     
    }
}
