/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.TransactionEntity;
import com.webapps2022.thrift.TimeClient;
import java.util.List;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateful
//@Stateless 
public class TransactionServiceBean implements TransactionService {
    
    @PersistenceContext
    EntityManager em;

    public TransactionServiceBean() {
    }
    @Override
    public List<TransactionEntity> getallTranList() {
        List <TransactionEntity> AllTran = em.createNamedQuery("findAllTran").getResultList();
        return AllTran;
    }
    @Override
    public List<TransactionEntity> getUserTranList(long User_id) {
       List <TransactionEntity> UserTran = em.createNamedQuery("findUserTran", TransactionEntity.class).setParameter("User_id", User_id).getResultList();
       return UserTran;
    }
    
    @Override
    public List<TransactionEntity> getUserTranToList(long Beneficial_No) {
       List <TransactionEntity> UserTran = em.createNamedQuery("findUserTranto", TransactionEntity.class).setParameter("Beneficial_No", Beneficial_No).getResultList();
       return UserTran;
    }
    
    @Override
    public void insertTransaction( long User_id, String Date, String Tran_Type, long Beneficial_No, float Amount, String Currency, float remainderbalance) {
        TransactionEntity NewTran = new TransactionEntity( User_id,  Date, Tran_Type,  Beneficial_No,   Amount,   Currency,   remainderbalance);
        //commentList.add(cmnt);
        em.persist(NewTran);
        System.out.println("Your transaction Succeed ");
    }
    @Override
    public String servertimestamp()
    {
    TimeClient c = new TimeClient();
        c.start();
        return c.time;
    }
}
