/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.RequestEntity;
import java.util.List;
import javax.ejb.Local;

@Local
public interface RequestService {
    
    public List<RequestEntity> getAllRequest(); 
    public List<RequestEntity> getUserRequest(long User_id);
    public List<RequestEntity> getmyRequest(long Benfi_id);
    public List<RequestEntity> findRequest(long Req_Tran_No);
    public void insertRequest(  long User_id, String Date, String Requ_state, float Amount, long Benfi_id, String Currency);
    public void updateRequest(String Requ_state,long Req_Tran_No);
    public String servertimestamp();
}
