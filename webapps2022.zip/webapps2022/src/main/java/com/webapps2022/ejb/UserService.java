/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.SystemUser;
//import java.util.Date;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author fakhr
 */
@Local
public interface UserService {
    public List<SystemUser> getUsersList();
    public void insertUsers(String username, String userpassword ,String name, String surename,String currancy);
    public List <SystemUser> authenticate(String username, String userpassword);
    public List <SystemUser> find(String username);
    public List <SystemUser> userdata(String username);
    public List <SystemUser> findusercurrancy(long id);
    public void registerUser(String username, String userpassword, String name, String surname,String currancy) ;
    public void createadmin(String username, String userpassword, String name, String surname,String currancy);
}
