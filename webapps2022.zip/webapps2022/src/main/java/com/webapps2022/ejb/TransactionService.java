/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.TransactionEntity;
import java.util.List;
import javax.ejb.Local;

@Local
public interface TransactionService {
    public List<TransactionEntity> getallTranList();
    public List<TransactionEntity> getUserTranList(long User_id);
    public List<TransactionEntity> getUserTranToList(long Beneficial_No);
     
    public void insertTransaction( long User_id, String Date, String Tran_Type, long Beneficial_No, float Amount, String Currency, float remainderbalance);
    public String servertimestamp();
}
    