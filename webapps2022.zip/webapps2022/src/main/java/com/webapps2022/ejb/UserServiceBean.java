
package com.webapps2022.ejb;

import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.SystemUserGroup;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
//import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
//import javax.transaction.Transactional;

@Stateless 
public class UserServiceBean implements UserService{

    //ArrayList<Comment> commentList;

    @PersistenceContext
    EntityManager em;

    public UserServiceBean() {
        //commentList = new ArrayList<>();
    }

    @Override
    public List<SystemUser> getUsersList() {
        List <SystemUser> users = em.createNamedQuery("findAllUsers").getResultList();
        return users;
    }
    
    //@Transactional(readOnly = true)
    @Override
    public List <SystemUser> authenticate(String username, String userpassword) {
    List <SystemUser> usersList = em.createNamedQuery("findUser",  SystemUser.class).setParameter("username", username).setParameter("userpassword", userpassword).getResultList();
    //UserEntity firstUserFromList = usersList.get(0);
    return usersList; //firstUserFromList;
    }
    @Override
    public List <SystemUser> userdata(String username) {
    List <SystemUser> usersList = em.createNamedQuery("finduserdata",  SystemUser.class).setParameter("username", username).getResultList();
    //UserEntity firstUserFromList = usersList.get(0);
    return usersList; //firstUserFromList;
    }
    @Override
    public List <SystemUser> find(String username) {
    List <SystemUser> usersList = em.createNamedQuery("find",  SystemUser.class).setParameter("username", username).getResultList();
    //SystemUser firstUserFromList = usersList.get(0);
    
    return usersList; //firstUserFromList;
    }
    
    @Override
    public List <SystemUser> findusercurrancy(long id) {
    List <SystemUser> usersList = em.createNamedQuery("findusercurrancy",  SystemUser.class).setParameter("id", id).getResultList();
    //SystemUser firstUserFromList = usersList.get(0);
    
    return usersList; //firstUserFromList;
    }
    
    @Override
    public void insertUsers(String username, String userpassword,String name, String surename,String currancy) {
        SystemUser Newuser = new SystemUser(username, userpassword, name, surename, currancy);
        //commentList.add(cmnt);
        em.persist(Newuser);
        
    }
 @Override
    public void registerUser(String username, String userpassword, String name, String surname,String currancy) {
        try {
            SystemUser sys_user;
            SystemUserGroup sys_user_group;

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String passwd = userpassword;
            md.update(passwd.getBytes("UTF-8"));
            byte[] digest = md.digest();
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < digest.length; i++) {
                sb.append(Integer.toString((digest[i] & 0xff) + 0x100, 16).substring(1));
            }
            String paswdToStoreInDB = sb.toString();

            // apart from the default constructor which is required by JPA
            // you need to also implement a constructor that will make the following code succeed
            sys_user = new SystemUser(username, paswdToStoreInDB, name, surname, currancy);
            sys_user_group = new SystemUserGroup(username, "users");

            em.persist(sys_user);
            em.persist(sys_user_group);

        } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void createadmin(String username, String userpassword, String name, String surname,String currancy) {
        try {
            SystemUser sys_user;
            SystemUserGroup sys_user_group;

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String passwd = userpassword;
            md.update(passwd.getBytes("UTF-8"));
            byte[] digest = md.digest();
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < digest.length; i++) {
                sb.append(Integer.toString((digest[i] & 0xff) + 0x100, 16).substring(1));
            }
            String paswdToStoreInDB = sb.toString();

            // apart from the default constructor which is required by JPA
            // you need to also implement a constructor that will make the following code succeed
            sys_user = new SystemUser(username, paswdToStoreInDB, name, surname, currancy);
            sys_user_group = new SystemUserGroup(username, "admins");

            em.persist(sys_user);
            em.persist(sys_user_group);

        } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @PostConstruct
    public void postConstruct() {
        System.out.println("UsersStore: PostConstruct");
    }

    @PreDestroy
    public void preDestroy() {
        System.out.println("UsersStore: PreDestroy");
    }
     
}
