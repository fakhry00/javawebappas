package com.webapps2022.restservice;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Application;
 

 
@Path("/conversion")
@ApplicationPath("/resources")
public class RestService extends Application {
 
	
	 
     	@GET
	@Path("/{c1}/{c2}/{Amount}")

        public CurrencyClass ex (@PathParam("Amount") float Amount,@PathParam("c1") String c1 ,@PathParam("c2") String c2)  
        {
            float exchangeRate = 0;
            if(c1.equals("USD ")){
                if( c2.equals("GBP "))
                exchangeRate = (float) 0.76; 
                else if( c2.equals("EUR "))
                exchangeRate = (float) 0.917;  }  
            else  if(c1.equals("GBP ")){
                if( c2.equals("USD "))
                exchangeRate = (float) 1.3;
                else if( c2.equals("EUR "))
                exchangeRate = (float) 1.2;  }  
            else if(c1.equals("EUR ")){
               if( c2.equals("USD "))
                exchangeRate = (float) 1.08;
                else if( c2.equals("GBP "))
                exchangeRate = (float) 0.8;
                            } 
            
              
             
            float result = exchangeRate * Amount;
        
            return new CurrencyClass(exchangeRate, Amount, c1, c2, result);
        
	 	
	}

}
