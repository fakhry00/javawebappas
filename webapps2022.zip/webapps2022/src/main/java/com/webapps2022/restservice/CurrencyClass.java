package com.webapps2022.restservice;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="CurrencyClass")
 
public class CurrencyClass {
    private float exchangeRate;
    private float amount;
    private String from;
    private String to;
    private float result;
    
    public CurrencyClass() {
    }
   
    public CurrencyClass(float exchangeRate, float amount, String from, String to, float result) {
        this.exchangeRate = exchangeRate;
        this.amount = amount;
        this.from = from;
        this.to = to;
        this.result = result;
    }

    public float getExchangeRate() {
        return exchangeRate;
    }

    public float getAmount() {
        return amount;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public float getResult() {
        return result;
    }

    public void setExchangeRate(float exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public void setResult(float result) {
        this.result = result;
    }

 @Override
	public String toString() {
		return "CurrencyClass [from=" + from + ",to=" + to + ",exchangeRate=" + exchangeRate + ", result=" + result + "]";
	}

    
}
