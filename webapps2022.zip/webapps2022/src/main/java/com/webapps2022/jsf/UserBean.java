
package com.webapps2022.jsf;


import com.webapps2022.entity.SystemUser;
//import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import com.webapps2022.ejb.UserService;
import java.io.Serializable;


@Named
//@RequestScoped
@SessionScoped
public class UserBean implements Serializable{
    
    String username;
    String userpassword;
    String name;
    String surname;
    String currancy;

    
   
    
    
    @EJB
    UserService store;
    
    
    public UserBean() {
    }

    public String getUsername() {
        return username;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }
    public String getCurrancy() {
        return currancy;
    }

    public void setCurrancy(String currancy) {
        this.currancy = currancy;
    }
   
    
    public String mySubmit() {
        store.insertUsers(username, userpassword, name, surname, currancy);
        return "public/newuser";
    }
    
    public List<SystemUser> getUsersList() {
        return store.getUsersList();
    }
    
   public String getvaliduser() { 
        List <SystemUser> user =  store.find(username); 
         
        if (user.isEmpty())
          return "0";
        else
          return user.toString().substring( 1, user.toString().length() - 1 );
    }
    
    public List <SystemUser> getvaliduser(String username) { 
        return store.find(username);             
       
    }
    
    public List <SystemUser> userdata(String username) { 
        return store.userdata(username);             
       
    }
    public String findusercurrancy(long id) { 
        List <SystemUser> currency =  store.findusercurrancy(id);
         if (currency.isEmpty())
          return "Null";
        else
          return currency.toString().substring( 1, currency.toString().length() - 1 );
       
    }
}
