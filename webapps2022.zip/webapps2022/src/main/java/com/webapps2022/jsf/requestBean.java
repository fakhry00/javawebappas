/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AccountService;
import com.webapps2022.ejb.RequestService;
import com.webapps2022.ejb.TransactionService;
import com.webapps2022.ejb.UserService;
import com.webapps2022.entity.AccountEntity;
import com.webapps2022.entity.RequestEntity;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.restservice.CurrencyClass;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

@Named
//@RequestScoped
@SessionScoped
public class requestBean implements Serializable{
      
     
    long User_id;
    String Date;
    String Requ_state;
    float Amount;
    long Benfi_id;
    String Currency;
    String to;
    String from;
    
    @EJB
    RequestService request;
    @EJB
    UserService store;
    @EJB
    AccountService st_account;
    @EJB
    TransactionService transaction;

    public long getUser_id() {
        return User_id;
    }

    public String getDate() {
        return Date;
    }

    public String getRequ_state() {
        return Requ_state;
    }

    public float getAmount() {
        return Amount;
    }

    public long getBenfi_id() {
        return Benfi_id;
    }

    public String getCurrency() {
        return Currency;
    }

    public void setUser_id(long User_id) {
        this.User_id = User_id;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public void setRequ_state(String Requ_state) {
        this.Requ_state = Requ_state;
    }

    public void setAmount(float Amount) {
        this.Amount = Amount;
    }

    public void setBenfi_id(long Benfi_id) {
        this.Benfi_id = Benfi_id;
    }

    public void setCurrency(String Currency) {
        this.Currency = Currency;
    }

     public String findusercurrancy(long id) { 
        List <SystemUser> currency =  store.findusercurrancy(id);
         if (currency.isEmpty())
          return "Null";
        else
          return currency.toString().substring( 1, currency.toString().length() - 1 );
       
    }
     public String insertrequest() {
        this.setCurrency(findusercurrancy(User_id));
        this.Requ_state = "0";
        this.setDate(request.servertimestamp());
        
        request.insertRequest( User_id, Date, Requ_state, Amount, Benfi_id, Currency);
        return "requestpay";
    }
     
    public void updateRequest(String Requ_state,long Req_Tran_No)
    {
     request.updateRequest(Requ_state,Req_Tran_No);
    }

    public List <RequestEntity> getUserRequest(long User_id) {
           List <RequestEntity> requ =  request.getUserRequest(User_id);
         return requ;
   } 
    
     public List <RequestEntity> findRequest(long Req_Tran_No) {
           List <RequestEntity> requ =  request.findRequest(Req_Tran_No);
         return requ;
   } 
    
    public List <RequestEntity> getmyRequest(long Benfi_id) {
           List <RequestEntity> requ =  request.getmyRequest(Benfi_id);
         return requ;
   }
    
    public boolean checkrequest(String Requ_state){         
        if (Requ_state.equals("0"))
            return false;
        else
            return true ;
    }
    public String showstate(String Requ_state)
    {
    if (Requ_state.equals("0"))
            return "Unpaid";
    else if (Requ_state.equals("1"))
            return "Paid" ;
    else if (Requ_state.equals("2"))
            return "Rejected" ;
    else
        return "Error";
    
    }
    public List <AccountEntity> showbalance(long Id ){
       List <AccountEntity> balance = st_account.findUserAccount(Id);
        
          return  balance ;      
         }
    
    public void updatebalance(long id, float balance)
    {
    st_account.updatebalance(id, balance);
    
    }
    // Exgange Currency using restfull service 
    public CurrencyClass ex() {
	Client client = ClientBuilder.newClient();
                float a =this.Amount;
                String To = to+" ";
                String From = from+" ";
	CurrencyClass RE = client.target("http://localhost:1000/webapps2022/resources/conversion/"+From+"/"+To+"/"+a).request().get(CurrencyClass.class);
        return RE;
                
	}
    // Payment transaction
     public String requestpayment(long Req_Tran_No){

         this.setDate(transaction.servertimestamp());
         List <RequestEntity> Frequest = findRequest(Req_Tran_No);
         this.User_id = Frequest.get(0).getUser_id();
         this.Amount = Frequest.get(0).getAmount();
         this.Benfi_id =Frequest.get(0).getBenfi_id();
         this.to = findusercurrancy(Benfi_id);
         this.from = findusercurrancy(User_id);
         float userBalance =  showbalance(User_id).get(0).getBalance();  
         float BeneficialBalance = showbalance(Benfi_id).get(0).getBalance();
         //Convert ammount to suitable currency
         float newamount = ex().getResult();
        if ( BeneficialBalance >= newamount ){ 
  
         //1- update benificial balance - newamount
         updatebalance(Benfi_id,BeneficialBalance - newamount);
 
         //2- insert transaction record
         transaction.insertTransaction(Benfi_id , Date, "WR", User_id, Amount, to ,BeneficialBalance - newamount);
             
         //3- update Beneficial balance  + amount
            float NewuserBalance = userBalance + Amount;
            updatebalance(User_id,NewuserBalance);
 
        //4- update request state to 1
         updateRequest("1", Req_Tran_No);
        
        System.out.print("payment has been completed");
            return "Requpaynotifications";
            }
        else {
            System.out.print("payment uncompleted");
            return "Requpaynotifications";}
     }
}
