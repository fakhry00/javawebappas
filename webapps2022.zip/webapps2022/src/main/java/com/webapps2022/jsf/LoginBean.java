package com.webapps2022.jsf;


import com.webapps2022.entity.AccountEntity;
import com.webapps2022.entity.SystemUser;
import java.io.Serializable;
import java.util.List;
import javax.annotation.ManagedBean;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

@Named
@ManagedBean
//@RequestScoped
@SessionScoped
public class LoginBean implements Serializable {

    private String username;
    private String password;

    @PersistenceContext
    EntityManager em;
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    // find user id 
    public List <SystemUser> find(String username) {
    List <SystemUser> usersList = em.createNamedQuery("finduserdata",  SystemUser.class).setParameter("username", username).getResultList();
    return usersList;  
    }
    //find user account
    public List <AccountEntity> findUserAccount(long UserId) {
    List <AccountEntity> useraccount = em.createNamedQuery("findUserAccount",  AccountEntity.class).setParameter("UserId", UserId).getResultList();
    return useraccount;  
    }

    public String login() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
        try {
            //this method will actually check in the realm you configured in the web.xml file for the provided credentials
            request.login(this.username, this.password);
        } catch (ServletException e) {
            context.addMessage(null, new FacesMessage("Login failed:" + e));
            return "error";
        }
        System.out.println(request.getRequestURI());
        
        if (request.isUserInRole("admins"))
            return "admin"; 
        else  {
            long id = find(username).get(0).getId();
            if(findUserAccount(id).isEmpty()){
                String log = logout();
                return "notactivate";}
                else
                return "user";
        }
       
    }

    public String logout() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        try {
            //this method will disassociate the principal from the session (effectively logging him/her out)
            request.logout();
            context.addMessage(null, new FacesMessage("User is logged out"));
        } catch (ServletException e) {
            context.addMessage(null, new FacesMessage("Logout failed."));
        }
       return "index"; 
    }
}
