/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AccountService;
import com.webapps2022.ejb.UserService;
import com.webapps2022.entity.AccountEntity;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.restservice.CurrencyClass;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

@Named
@RequestScoped
public class account implements Serializable {

    long UserId;
    float Balance;
    String t;
    List <AccountEntity> acc;
    @EJB
    AccountService st_account;
     @EJB
    UserService store;

    public void setAcc(List<AccountEntity> acc) {
        this.acc = acc;
    }

    public List<AccountEntity> getAcc() {
        return acc;
    }

    public String getT() {
        return t;
    }

    public void setT(String t) {
        this.t = t;
    }



    public void setUserId(long UserId) {
        this.UserId = UserId;
    }

    public void setBalance(float Balance) {
        this.Balance = Balance;
    }

    public long getUserId() {
        return UserId;
    }

    public double getBalance() {
        return Balance;
    }
    // Exgange Currency using restfull service 
    public CurrencyClass ex() {
	Client client = ClientBuilder.newClient();
        
	CurrencyClass RE = client.target("http://localhost:1000/webapps2022/resources/conversion/GBP /"+t+"/"+1000).request().get(CurrencyClass.class);
        return RE;
                
	}
    public String findusercurrancy(long id) { 
        List <SystemUser> currency =  store.findusercurrancy(id);
         if (currency.isEmpty())
          return "Null";
        else
          return currency.toString().substring( 1, currency.toString().length() - 1 );
       
    }
    public String create(long Id ){
        if(st_account.findUserAccount(Id).isEmpty()) {
            this.t = findusercurrancy(Id)+" ";
           st_account.InsertAccount(Id,ex().getResult());
           this.setT("success");}
        else 
           this.setT("The account already exists"); 
               
        return "activateusers";}
    
    public List <AccountEntity> showaccount(long Id ){
       List <AccountEntity> balance = st_account.findUserAccount(Id);     
        return balance;
    }
    public boolean checkaccount(long Id ){
       List <AccountEntity> balance = st_account.findUserAccount(Id);
           
        if( balance.isEmpty())
            return false;
        else
            return true;
    }
            
    
    @Override
    public String toString() {
    return "account [UserId=" + UserId + ", Balance=" + Balance + "]";
 }

    private List<AccountEntity> AccountEntity() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
