/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;


import com.webapps2022.ejb.AccountService;
import com.webapps2022.ejb.TransactionService;
import com.webapps2022.entity.TransactionEntity;
import com.webapps2022.ejb.UserService;
import com.webapps2022.entity.AccountEntity;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.restservice.CurrencyClass;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

@Named
//@RequestScoped
@SessionScoped
public class TransactionBean implements Serializable {
    
    long User_id;
    long Tran_No;
    
    String Date;
    String Tran_Type;
    long Beneficial_No;
    int Amount;
    String Currency;
    float remainderbalance;
    private String from;
    private String to;
    
    @EJB
    TransactionService transaction;
    @EJB
    UserService store;
    @EJB
    AccountService st_account;

    public float getRemainderbalance() {
        return remainderbalance;
    }

    public void setRemainderbalance(float remainderbalance) {
        this.remainderbalance = remainderbalance;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    } 
    
    public long getUser_id() {
        return User_id;
    }

    public long getTran_No() {
        return Tran_No;
    }

    public String getDate() {
        return Date;
    }

    public String getTran_Type() {
        return Tran_Type;
    }

    public long getBeneficial_No() {
        return Beneficial_No;
    }

    public int getAmount() {
        return Amount;
    }

    public String getCurrency() {
        return Currency;
    }

    public void setUser_id(long User_id) {
        this.User_id = User_id;
    }

    public void setTran_No(long Tran_No) {
        this.Tran_No = Tran_No;
    }

    public void setDate(String Date) {
        
        this.Date =  Date;//servertimestamp();
    }

    public void setTran_Type(String Tran_Type) {
        this.Tran_Type = Tran_Type;
    }

    public void setBeneficial_No(long Beneficial_No) {
        this.Beneficial_No = Beneficial_No;
    }

    public void setAmount(int Amount) {
        this.Amount = Amount;
    }

    public void setCurrency(String Currency) {
        this.Currency = Currency;
    }
   // payment Transaction 
    
     public String findusercurrancy(long id) { 
        List <SystemUser> currency =  store.findusercurrancy(id);
         if (currency.isEmpty())
          return "Null";
        else
          return currency.toString().substring( 1, currency.toString().length() - 1 );
       
    }
     
    public List <AccountEntity> showbalance(long Id ){
       List <AccountEntity> balance = st_account.findUserAccount(Id);
        
          return  balance ;      
         }
    
    public void updatebalance(long id, float balance)
    {
    st_account.updatebalance(id, balance);
    
    }
    // Exgange Currency using restfull service 
    public CurrencyClass ex() {
	Client client = ClientBuilder.newClient();
                int a =this.Amount;
                String To = to+" ";
                String From = from+" ";
	CurrencyClass RE = client.target("http://localhost:1000/webapps2022/resources/conversion/"+From+"/"+To+"/"+a).request().get(CurrencyClass.class);
        return RE;
                
	}
    
    public String inserttrans() {
        this.Tran_Type = "WR";
        // get Timestape from server and asign it to Date
        this.setDate(transaction.servertimestamp());
        this.from = findusercurrancy(User_id);
        this.to = findusercurrancy(Beneficial_No);
        float userBalance =  showbalance(User_id).get(0).getBalance();  
        float BeneficialBalance = showbalance(Beneficial_No).get(0).getBalance();
        if ( userBalance >= Amount ){
            
            //1- update user balance (remainderbalance)
             this.remainderbalance = userBalance - Amount;
             updatebalance(User_id,remainderbalance);
             
            //2- Convert ammount to suitable currency and update benificial balance + newamount 
            float newamount = ex().getResult();
            
            //3- insert transaction record
            transaction.insertTransaction(User_id , Date, Tran_Type, Beneficial_No, Amount, from ,remainderbalance);
             
            //4- update Beneficial balance  + amount
            float NewBeneficialBalance = BeneficialBalance + newamount;
            updatebalance(Beneficial_No,NewBeneficialBalance);
            
            System.out.print("payment has been completed");
            return "user";
            }
        else {
            System.out.print("payment uncompleted");
            return "newpayment";}
    }

 public List <TransactionEntity> getUsersList() {
        return transaction.getallTranList();
    }
 public List <TransactionEntity> getUserTranList(long User_id) {
        List <TransactionEntity>trans =  transaction.getUserTranList(User_id);
         return trans;
   } 
 
 public List <TransactionEntity> getUserTranToList(long User_id) {
        List <TransactionEntity>trans =  transaction.getUserTranToList(User_id);
         return trans;
   } 

   
 
 
}
