package com.webapps2022.jsf;


import com.webapps2022.restservice.CurrencyClass;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

@ApplicationScoped
@ManagedBean
public class RestClient {
        
    private float exchangeRate;
    private int amount;
    private String from;
    private String to;
    private int result;

    public float getExchangeRate() {
        return exchangeRate;
    }

    public int getAmount() {
        return amount;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public int getResult() {
        return result;
    }

    public void setExchangeRate(float exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public void setResult(int result) {
        this.result = result;
    }

  

	 
    public CurrencyClass ex() {
	Client client = ClientBuilder.newClient();
                
	CurrencyClass RE = client.target("http://localhost:1000/RestExample/resources/RestService/conversion/"+from+"/"+to+"/"+amount).request().get(CurrencyClass.class);
        return RE;
                
	}
         
        
         
}
