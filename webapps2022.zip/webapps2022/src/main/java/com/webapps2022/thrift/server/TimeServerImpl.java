package com.webapps2022.thrift.server;

import java.sql.Timestamp;
 

import org.apache.thrift.TException;
import com.webapps2022.thrift.server.TimeService;
class TimeServerImpl implements TimeService.Iface {
   @Override
   public String time() throws TException {
      //long time = System.currentTimeMillis();
      Timestamp time = new Timestamp(System.currentTimeMillis());
      System.out.println("Sent Timestamp: " + time);
      return time.toString();
   }
}
 
