 
package com.webapps2022.thrift;

 
import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;
import com.webapps2022.thrift.TimeService.Client;
public class TimeClient {
   public String time;
   public void start(){
      TTransport transport;
      try {
         transport = new TSocket("localhost", 10002);
         TProtocol protocol = new TBinaryProtocol(transport);Client client = new Client(protocol);
         transport.open();
         String time = client.time();
         //System.out.println("Time from server:" + time);
         this.time = time;
         transport.close();
         
      
      } catch (TTransportException e) {
         e.printStackTrace();
      } catch (TException e) {
         e.printStackTrace();
      }
        
   }

    public void setTime() {
        TimeClient c = new TimeClient();
        c.start();
         
    }

    public String getTime() {
        return time;
    }
 
  
}