package com.webapps2022.thrift.server;

 
 
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TServer.Args;
import org.apache.thrift.server.TSimpleServer;
import org.apache.thrift.transport.TServerSocket;
import org.apache.thrift.transport.TServerTransport;
@Startup 
@Singleton
public class Server {
   
    public static TimeServerImpl handl;
    public static TimeService.Processor processor;
    public static TServerTransport serverTransport;
    public static TServer server;

    
    private void startServer() {
        try {
            handl = new TimeServerImpl();
            processor = new TimeService.Processor(handl);

            Runnable simple = new Runnable() {
                @Override
                public void run() {
                    simple(processor);
                }
            };

            new Thread(simple).start();
            //System.in.read();
            //server.stop();
            
        } catch (Exception x) {
            System.err.println(x);
        }
    }

    public static void simple(TimeService.Processor processor) {
        try {
            serverTransport = new TServerSocket(10002);
            server = new TSimpleServer(new Args(serverTransport).processor(processor));

            System.out.println("Starting the simple server in Thread " + Thread.currentThread().getId());
            server.serve();
        } catch (Exception e) {
            System.err.println(e);
        }
    }
    
    @PostConstruct
    public void init() {
        startServer();
    }
    
    @PreDestroy
    public void StopServer(){
        server.stop();
    }

}
